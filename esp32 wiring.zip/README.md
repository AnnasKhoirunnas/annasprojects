# control-output-multiboard (ESP8266/ESP32)

Features:
- CRUD Data Device
- set GPIO dynamic
- set output type (Active HIGH/LOW)

Platform Technology: PHP, MySQL, Bootstrap 4
Hardware Technology: IDE Arduino, ESP8266, ESP32

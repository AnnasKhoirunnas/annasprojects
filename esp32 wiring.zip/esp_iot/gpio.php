<?php 
require "template.php";


 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<title></title>
 </head>
 <body>
 	<center>
 		<h4 class="mt-4">GPIO ESP8266 - ESP32</h4>
 		<a href="index.php" class="btn btn-success mt-2"><i class="fa fa-home"></i></a>
 		<br>

 		 <img class="img-fluid responsive-sm mt-3" src="img/GPIO ESP8266.png" alt="Responsive image">
 		 <img class="img-fluid responsive-sm mt-3" src="img/GPIO ESP32.png" alt="Responsive image">


 	</center>
 	
 
 </body>
 </html>